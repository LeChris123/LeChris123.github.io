
import time

start = int(input('Enter a positive number: '))
stop = -1 
iterate = -1
for i in range (start, stop, iterate):
        print(i)
        time.sleep(1)

