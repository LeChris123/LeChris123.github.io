print ('Counts from 10-0')
x = 10
while x > -1:
    print(x)
    x = x - 1
