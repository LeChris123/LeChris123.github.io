start = 10
stop = -1
iterate = -1
for i in range (start,stop, iterate):
    print(i)
