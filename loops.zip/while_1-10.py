print('Counts from 1-10')
x = 1
while x < 11:
    print (x)
    x = x + 1
