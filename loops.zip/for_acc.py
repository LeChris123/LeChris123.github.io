#accumulator countdown
import time

acc = 10

for i in range (acc):
    print (acc)
    acc = acc-1
    time.sleep (1)
