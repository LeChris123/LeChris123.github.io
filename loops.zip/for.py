for i in range(10):
    print (i)


start = 0
stop = 20
iterate = 2
for i in range (start,stop, iterate):
    print(i)

print('Counts from 1-10')
start = 1
stop = 11
iterate = 1
for i in range (start,stop, iterate):
    print(i)
