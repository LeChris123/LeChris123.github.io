import time
print ('Input a positive number.')
x = int(input())
while x > -1:
    print (x)
    x = x -1 
    time.sleep (1)
